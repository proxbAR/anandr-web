var typed = new Typed('.first',{
  strings:["<h1>Hello.</h1>","<h1>I'm Anand.</h1>","<h1>I'm a <strong>Web Developer</strong>,</h1>","<h1>And <strong>Graphic Designer.</strong></h1>","<h1>Welcome to my website!</h1>"],
  backSpeed: 50,
  typeSpeed: 50,
  loop: true
});